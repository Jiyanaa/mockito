package mockito;

public interface LoginServiceImp {
	public void login(User user);

}
