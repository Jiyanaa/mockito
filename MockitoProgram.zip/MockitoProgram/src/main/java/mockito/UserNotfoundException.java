package mockito;

public class UserNotfoundException extends Exception {
	
	public UserNotfoundException() {
		super("No such user exist");
	}
}
