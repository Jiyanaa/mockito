package mockito;

public class NoUsersInThisCityException extends Exception{
	
	public NoUsersInThisCityException() {
		super("No user in this city");
	}

}
