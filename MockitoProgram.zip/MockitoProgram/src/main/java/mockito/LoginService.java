package mockito;

import java.util.List;

public class LoginService{
	
	private UserDao userDao;
	
	public void setUserDao(UserDao userDao) {
		this.userDao = userDao;
		
	}
	
	
	public boolean login(String userName, String password) {
		boolean valid = false;
		User user = userDao.loadByUserNameAndPassword(userName,  password);
		if(user != null) {
			valid = true;
		}
		return valid;	
	}
	
	public User getUserByUserName(String userName){
		User user = userDao.getUserByUserName(userName);
		return user;
		
	}
	
	public List<User>getUsersByCity(String city){
		return userDao.getUserByCity(city);
	}
	
	public void addUser(User user) throws InvalidUserDetailsException{
		userDao.addUser(user);
	}



}
