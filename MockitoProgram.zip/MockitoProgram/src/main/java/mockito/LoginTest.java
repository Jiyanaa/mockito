package mockito;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

import java.util.List;


import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

public class LoginTest {
	@Mock
	UserDao userDao;
	
	private List<String> list;
	LoginService loginService;
	@BeforeEach
	public void setup(){
		MockitoAnnotations.initMocks(this);
	}
	
	@Test
	public void testLogin() {
		User user = new User();
		user.setCity("chennai");
		user.setUserName("ram");
		user.setPassword("jack123");
		when(userDao.loadByUserNameAndPassword("jack", "jack123")).thenReturn(user);
		loginService = new LoginService();
		loginService.setUserDao(userDao);
		Boolean actual = loginService.login("jack","jack123");
		Boolean expected = true;
		assertEquals(expected, actual);
	}
	
	@Test
	public void testLogin2() {
		
		when(userDao.loadByUserNameAndPassword("jack", "jack123")).thenReturn(null);
		loginService = new LoginService();
		loginService.setUserDao(userDao);
		Boolean actual = loginService.login("jack", "jack123");
		Boolean expected=false;
		assertEquals(expected, actual);
	}
	
	@Test
	public void testLogin3()
	{
		when(userDao.getUserByUserName("jack")).thenAnswer(invocation -> {
			throw new UserNotfoundException();
		});
		loginService = new LoginService();
		loginService.setUserDao(userDao);
		
		assertThrows(UserNotfoundException.class, ()->loginService.getUserByUserName("jack"));
	}
	
	@Test
	public void testLogin4() {
		when(userDao.getUserByCity("chennai")).then(invocation -> {
			throw new NoUsersInThisCityException();
		});
		
		loginService = new LoginService();
		loginService.setUserDao(userDao);
		
		assertThrows(NoUsersInThisCityException.class,() ->loginService.getUsersByCity("chennai"));
		
	}
	
	@Test
	public void testLogin5() {
		User user = new User();
		doThrow(new InvalidUserDetailsException()).when(userDao).addUser(user);
		loginService = new LoginService();
		loginService.setUserDao(userDao);
		assertThrows(InvalidUserDetailsException.class,()->loginService.addUser(user));
		verify(userDao,times(1)).addUser(any(User.class));
	}
}
