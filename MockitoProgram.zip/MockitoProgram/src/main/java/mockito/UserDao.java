package mockito;

import java.util.List;

public interface UserDao {
	
	User loadByUserNameAndPassword(String username, String password);
	User getUserByUserName(String userName);
	
	List<User> getUserByCity(String city);
	void addUser(User user);

}
