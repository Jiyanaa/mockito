package mockito;

public class Starter {
	public static void main(String[] args) {
		
		User user = new User();
		user.setUserName("jack");
		user.setUserName("jack123");
		boolean b = new LoginService().login("jack","jack123");
		if(b) {
			System.out.println("login successful");
		}
		else {
			System.out.println("login failed");
		}
	}

}
